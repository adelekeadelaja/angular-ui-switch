﻿/*
 * angular-ui-switch
 * by Adeleke Adelaja
 * https://github.com/adelekeadelaja/angular-ui-switch
 * 
 * Version: 1.0.0
 * 
 * Demo: http://dwleke.info/angular-ui-switch
 */
angular.module('ui-switch', [])
    .directive('uiswitch', [function () {
        return {
            restrict: 'EA',
            transclude: true,
            template: '<style type="text/css">.switch-slide,.switch-slide-on {display:inline-block; vertical-align:text-top; width:50px; height:10px; border-radius:5px; margin:5px 10px; cursor:pointer; background-color:lightgrey;}'
                        + '.switch-slide-on {background-color:rgba(0, 5, 255, 0.5);}'
                        + '.switch-off, .switch-on {width: 20px;height: 20px;border-radius: 50%;position: relative;top: -5px;left: 0;-moz-box-shadow: rgba(0,0,0,0.5)0px 0px 5px;-webkit-box-shadow: rgba(0,0,0,0.5)0px 0px 5px;box-shadow: rgba(0,0,0,0.5)0px 0px 5px;background-color: inherit;}'
                        + '.switch-on {position: relative;left: 30px;-moz-box-shadow: rgb(0, 5, 255)0px 0px 5px;-webkit-box-shadow: rgb(0, 5, 255)0px 0px 5px;box-shadow: rgb(0, 5, 255)0px 0px 5px;background-color: rgb(0, 5, 255);}'
                        + '</style><div ng-class="slideState()" ng-click="switched()"><div ng-class="switchState()"></div></div>',
            scope: { mode: '=', text: '=' },
            controller: ['$scope', function ($scope) {
                // defines the state of the switch i.e. On/Off
                $scope.mode = false; 

                // classes - identifies the state of the switch
                $scope.slideState = function () {
                    return $scope.mode ? 'switch-slide-on' : 'switch-slide';
                }

                $scope.switchState = function () {
                    return $scope.mode ? 'switch-on' : 'switch-off';
                }

                // turn on/off the switch
                $scope.switched = function () {
                    $scope.mode = !$scope.mode;
                };
            }]
        }
    }])